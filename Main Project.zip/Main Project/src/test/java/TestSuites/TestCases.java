package TestSuites;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Base.Base;
import Pages.CarWash;
import Pages.Flisting;
import Pages.RetreiveItems;

public class TestCases extends Base{
	CarWash cw = new CarWash();
	Flisting fl = new Flisting();
	RetreiveItems rit = new RetreiveItems();
	
	@BeforeTest
	public void invokeBrowser() throws Exception 
	{
		logger = report.createTest("Executing Test Cases");
		cw.invokeBrowser();
		reportPass("Browser is Invoked");
	}
	
	@Test(priority = 1)
	public void carwashing() throws Exception
	{
		cw.carwash();
		reportPass("Car Washing data's are retrieved");
	}
	
	@Test(priority = 2)
	public void listing() throws Exception
	{
		fl.register();
		reportPass("Errors obtained in the free listing Page");
	}
	
	@Test(priority = 3)
	public void retrieve()
	{
		rit.items();
		reportPass("SubMenu's are obtained");
	}
	
	@AfterTest
	public void closeBrowser()
	{
		rit.endReport();
		rit.closeBrowser();
	}
	
	

}
