package utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentReportManager {
	public static ExtentReports report;

	public static ExtentReports getReportInstance() {
		if (report == null) {
			ExtentSparkReporter sparkreporter = new ExtentSparkReporter(
					System.getProperty("user.dir") + "\\Report\\Report.html");
			report = new ExtentReports();
			report.attachReporter(sparkreporter);

			report.setSystemInfo("OS", "Windows 10");
			

			sparkreporter.config().setDocumentTitle("Car Wash Services");
			sparkreporter.config().setReportName("Identify Car Wash Services");
			sparkreporter.config().setTimeStampFormat("MMM dd, yyyy HH:mm:ss");
		}
		return report;
	}

}
