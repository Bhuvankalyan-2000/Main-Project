package Base;

import static org.testng.Assert.assertFalse;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import io.github.bonigarcia.wdm.WebDriverManager;
import utils.ExtentReportManager;

public class Base {

	public static WebDriver driver;
	public static Properties prop;
	public static WebDriverWait wait;
	public ExtentReports report = ExtentReportManager.getReportInstance();
	public ExtentTest logger;

	/****************** To Call different browsers ******************/
	
	public void invokeBrowser() throws Exception {
		prop = new Properties();
		FileInputStream inputStream;

		inputStream = new FileInputStream(
				System.getProperty("user.dir") + "\\src\\main\\java\\Config\\config.properties");
		prop.load(inputStream);

		/****************** To open chrome Browser ******************/

		if (prop.getProperty("browserName").matches("chrome")) {
			WebDriverManager.chromedriver().setup();
			ChromeOptions options = new ChromeOptions();
			options.addArguments("start-maximized");
			options.addArguments("--disable-blink-features=AutomationControlled");
			options.addArguments("--disable-notifications");// Disabling any notifications
			driver = new ChromeDriver(options);
		}

		/****************** To open firefox Browser ******************/

		if (prop.getProperty("browserName").matches("firefox"))
			try {
				WebDriverManager.firefoxdriver().setup();
				FirefoxOptions options = new FirefoxOptions();
				options.addArguments("start-maximized");
				options.addArguments("--disable-blink-features=AutomationControlled");
				options.addArguments("--disable-notifications");
				driver = new FirefoxDriver(options);

			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(60));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
	}

	/******************To open the mainpage URL ******************/
	
	public void openURL(String URL) {
		driver.get(prop.getProperty(URL));
		
	}

	/****************** Reporting Functions ***********************/

	public void reportFail(String reportString) {
		logger.log(Status.FAIL, reportString);
		

		assertFalse(false, reportString);
	}

	public void reportPass(String reportString) {
		logger.log(Status.PASS, reportString);
	}

	/****************** Capture Screen Shot ***********************/

	public void takeScreenShot(String fileName) {
		TakesScreenshot takeScreenShot = (TakesScreenshot) driver;
		File sourceFile = takeScreenShot.getScreenshotAs(OutputType.FILE);

		File destFile = new File(
				System.getProperty("user.dir") + "//Screenshots//" + fileName + ".png");
		try {
			FileUtils.copyFile(sourceFile, destFile);
			logger.addScreenCaptureFromPath(
					System.getProperty("user.dir") + "//Screenshots//" + fileName + ".png");

		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	/****************** To input all the data to the report  ******************/
	
	public void endReport()
	{
		report.flush();
	}
	
	/****************** Close the browser ******************/
	
	public void closeBrowser()
	{
		driver.quit();
	}
	/*@Test
	public void mat()
	{
		System.out.println(System.getProperty("user.dir") + "\\src\\main\\java\\Config\\config.properties");
	}*/
}
