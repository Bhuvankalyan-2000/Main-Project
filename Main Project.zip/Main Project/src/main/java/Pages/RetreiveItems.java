package Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import Base.Base;

public class RetreiveItems extends Base {

	By fitness = By.xpath("//*[@id=\"hotkeys_text_24\"]");
	By gym = By.xpath("//*[@id=\"mnintrnlbnr\"]/ul/li[3]/a/span[2]");
	By opt = By.xpath("//span[@class = 'meditle1 lng_commn']");

	public void items() {
		logger = report.createTest("Getting the submenu of gym's");
		try {
			openURL("URL");
			driver.findElement(fitness).click();
			driver.findElement(gym).click();
			reportPass("Gym Sub-Menu items :");
			List<WebElement> options = driver.findElements(opt);
            System.out.println("**********  Sub Menu Items  **********");
			for (WebElement option : options) {
				System.out.println(option.getText());
			}
			reportPass("All the Submenu's are obtained Successfully");

		} catch (Exception e) {
			reportFail(e.getMessage());
		}
	}
}
