package Pages;

import java.io.FileInputStream;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;

import Base.Base;

public class Flisting extends Base {

	By list = By.id("h_flist");
	By mobile = By.xpath("//*[@id=\"fmb0\"]");
	By submit = By.xpath("//*[@id=\"add_div0\"]/div[3]/button");
	By error = By.id("fcoe");

	public void register() throws Exception {
		logger = report.createTest("Trying to list in Free Listing");
		try {
			openURL("URL");
			driver.findElement(list).click();
			reportPass("Free Listing Page is Opened");
			FileInputStream fis = new FileInputStream(
					System.getProperty("user.dir") + "\\src\\test\\resources\\TestData.xlsx");
			@SuppressWarnings("resource")
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheet("Sheet1");
			driver.findElement(mobile).sendKeys(sheet.getRow(1).getCell(0).getStringCellValue());
			reportPass("Invalid data is entered in the Mobile Number Field");
			driver.findElement(submit).click();
			reportPass("Submit the data");
			String value = driver.findElement(error).getText();
			System.out.println();
			System.out.println("**********  Provide Invalid Details in FreeListing Page and Get Error Message  **********");
			System.out.println("Invalid Input Error Message :" + value);
			System.out.println();
			takeScreenShot("Flist");
			reportPass("Error Appeared");
		} catch (Exception e) {
			reportFail(e.getMessage());
		}
	}
}
