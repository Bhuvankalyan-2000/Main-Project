package Pages;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import Base.Base;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CarWash extends Base {
	By city = By.id("city");
	By choice = By.id("Chennai");
	By care = By.id("hotkeys_text_5");
	By wash = By.xpath("//span[text()='Car Wash']");
	By ratings = By.xpath("//span[@class='green-box']");
	By names = By.xpath("//span[@class='lng_cont_name']");
	By cont = By.xpath("//p[@class='contact-info ']");
	By vote = By.xpath("//p[@class='newrtings ']/descendant::span[starts-with(@class,'rt_count')]");
	By rate = By.className("lng_srtfltr");

	public void carwash() throws Exception {
		logger = report.createTest("Getting Car Washes greater than 4.0 rating");
		
		try {
			openURL("URL");
			takeScreenShot("HomePage");
			driver.findElement(city).click();
			driver.findElement(choice).click();
			driver.findElement(care).click();
			Thread.sleep(3000);
			driver.findElement(wash).click();
			Actions actions = new Actions(driver);
			WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
			wait.pollingEvery(Duration.ofSeconds(10));
			WebElement cross = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"best_deal_div\"]/section/span")));
			actions.moveToElement(cross).click().perform();
			
			Thread.sleep(3000);
			takeScreenShot("Car Wash");
			driver.findElement(rate).click();
			reportPass("Car Wash Page is Clicked");
			List<WebElement> Ratings = driver.findElements(ratings);
			List<WebElement> Names = driver.findElements(names);
			List<WebElement> Contacts = driver.findElements(cont);
			List<WebElement> Votes = driver.findElements(vote);
			System.out.println();
			System.out.println("**********  List of Car Wash Services with Ratings > 4 & Votes > 20  **********");
			int n = Votes.size();
			int count = 0;

			for (int i = 0; i < n; i++) {
				float rate = Float.parseFloat(Ratings.get(i).getText());
				String vote1 = Votes.get(i).getText();
				String numberOnly = vote1.replaceAll("[^0-9]", "");
				int VoteInteger = Integer.parseInt(numberOnly);

				if (rate > 4 && VoteInteger > 20) {
					System.out.println(Ratings.get(i).getText() + " - " + Names.get(i).getText() + " - "
							+ Contacts.get(i).getText());
					reportPass("Car Washing Services Name and Ratings are obtained");
					count++;
					if (count >= 5)
						break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			reportFail(e.getMessage());
			// TODO: handle exception
		}
	}

}
